#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <iomanip>
#include <stdio.h>

using namespace std;


struct mobile_host{
	mobile_host * next;                                    // its next mobile host
	int phone_num;                                         // mobile host number
	int numberofbase;                                      // it stores the base number of mobile host
};


struct base_station{
	base_station * next;                                    // its next base stations
	base_station *child;                                    // its child base stations 
	base_station *parent;                                   // its parent base stations
	mobile_host *linklist;                                  // stores the address of first mobile host
	int num;                                                // base station number
};



struct List{
	void create();
	base_station* close(base_station*s);
	void add_base(int, int);
	void add_host(int, int);
	void fullpath(int, base_station*, base_station*);
	void messages(char *);
	void control(int, mobile_host*);
	void search_base(int, base_station*);
	mobile_host* close_mh(mobile_host*);
	mobile_host *where; 
	base_station *find;
	base_station *head;
};

typedef List Phone;

Phone phoneapp;



int main(int arg_count, char **args){                                   //this function takes files as inputs and reads Network.txt and makes the tree
	int child, base;
	FILE *fptr;
	char * filename1 = args[1];
    char base_type[3];
	
	phoneapp.create();
	if((fptr = fopen(filename1 ,"r"))==NULL){                           // opening file
		printf("File couldn't be opened");
		return 0;
	}
	while(!feof(fptr)){                                                 // reading file
		fscanf(fptr, "%s %d %d ", base_type, &child, &base);
		if(base_type[0]=='B' && base_type[1]=='S'){
			phoneapp.add_base(child, base);                             // adding base stations
		}else if(base_type[0]=='M' && base_type[1]=='H'){
			phoneapp.add_host(child, base);                             // adding mobile hosts
		}
	}
	
	phoneapp.messages(args[2]);                                         // printing the outputs
	
	
	fclose(fptr);                                                       // closing the file
}


void List::create(){                                                    // this function creates the first base station at first
	base_station* first = new base_station();
	first->next = NULL;
	first->child = NULL;
	first->linklist = NULL;
	first->num = 0;
	head = first;
	return;
}

void List::add_base(int child, int base){
	base_station *traverse = head;
	base_station *newnode = new base_station();                         // creating the base station
	newnode->num = child;
	newnode->next = NULL;
	newnode->child = NULL;
	newnode->linklist = NULL;
	if(base==0){                                                        // if its base is 0 it we don't need to search for child and next
		if(head->next==NULL){
			traverse->next = newnode;
			return;
		}else{
			while(traverse->next!= NULL){
				traverse = traverse->next;
			}
			if(traverse->next == NULL){
				traverse->next = newnode;
			}
		}
	}else{                                                              // its base is not 0, so we must search for 
		base_station *tail=head;
		find = NULL;
		tail = head;
		tail = tail->next;
		search_base(base, tail);                                        // searching for base station
		newnode->parent = find;
		if(find->child==NULL){                                          // after finding it addition process changes due to its child and next
			find->child = newnode;
			return;
		}else{
			find = find->child;
			while(find->next != NULL){
				find = find->next;
			}
			find->next = newnode;
			
		}

	}
	
		
}


void List::add_host(int ch_link, int bs_link){
	
	mobile_host *newnode = new mobile_host();
	newnode->next = NULL;
	newnode->phone_num = ch_link;
	newnode->numberofbase = bs_link;
	base_station *tail=head;

	find = NULL;
		
	search_base(bs_link, tail);                                         // here we find the base which we will add mobile host

	if(find->linklist==NULL){                                           // this part is addition process depending on different cases
		find->linklist = newnode;
	}else{
		mobile_host* proper = find->linklist;
		
		while(proper->next!=NULL){
			proper = proper->next;
		}
		proper->next = newnode;
	}
	
}

void List::search_base(int base, base_station *traverse){               // this function finds the address of searhed base station

	if(traverse->num != base && find==NULL){
		find=NULL;
	}else{
		find=traverse;
	}
	
	if(traverse->child!= NULL && traverse->num != base && find == NULL){		// while program don't find the base station ' find == NULL ' is statisfies so it searches in child base stations 
		search_base(base, traverse->child);
	}

	if(traverse->next!=NULL && traverse->num != base && find==NULL){            // if progam don't find the base station it searches in next base stations
		search_base(base, traverse->next);
	}
	
}


void List::fullpath(int number, base_station *traverse, base_station*memory){
	
	cout<<" " <<traverse->num;
	if(traverse->linklist!=NULL){
		control(number, traverse->linklist);              // controlling that the mobile host is in that base station or not if not the ' where == NULL ' will be satisfies so program will search for mobile host in child and next base stations
	}
	
	if(traverse->child!= NULL   && where==NULL){
		fullpath(number, traverse->child,traverse->child);  // moving to child base station
	}

	if(traverse->next!=NULL  && where==NULL){
		fullpath(number, traverse->next,traverse->next);    // moving to next base station
	}

}

void List::control(int number, mobile_host* headof){      // controls the mobile host is in that base station or not
	mobile_host* traverse = headof;
	while(traverse->next!=NULL && traverse->phone_num!=number){
		traverse = traverse->next;
	}
	if(traverse->phone_num!=number){
		where = NULL;
	}else{
		where = traverse;                                 // if program find the mobile host it will make where to show its address
	}
}

void List::messages(char *str){                      // that function is for printing outputs
	//base_station* finalnode;
	base_station* memory;
	FILE * fptr2;
	char mystring [1000];
	char* filename2 = str;

	if((fptr2 = fopen(filename2,"r"))==NULL){
		printf("File couldn't be opened");
		return ;
	}
	while((fgets(mystring , sizeof(mystring) , fptr2))!=NULL){
		mystring[strlen(mystring)-1] = '\0';
		int multipler = 1;
		int sum = 0;
		int i  = strlen(mystring)-1;
		while(mystring[i]!='>'){
			sum+=(mystring[i]-'0')*multipler;
			multipler = multipler* 10;
			i--;
		}
		cout<< "Traversing:0";
		where = NULL; 
		fullpath(sum, head->next,head->next);                           // finding mobile host in base stations and printing visited base stations while searching  
		cout<<endl;
		find = NULL;
		memory = head;
		if(where!= NULL){
			search_base(where->numberofbase,memory->next);              // this function finds the address of searched base station
		}
		if(where==NULL){
			cout<<"Can not be reached the mobile host mh_"<<sum<<" at the moment"<<endl;
		}else{
			int i=0;
			cout<<"Message:";
			while(mystring[i]!='>'){
				cout<<mystring[i];
				i++;
			}
			cout<<" To:0";
			int arr[1000];
			int j=-1;
			while(find != NULL){
				j++;
				arr[j]=find->num;
				find = find->parent;
				
			}
			for(int t=j;t>=0;t--){
				cout<<" "<<arr[t];
			}
			cout<<" mh_"<<where->phone_num<<endl;	
		}
	}
	close(head);                                       // closing whole tree
	//head=NULL;
	//find = NULL;
	//where = NULL;
	fclose(fptr2);                                      //closing the file
	
}

base_station* List::close(base_station* traverse){
	
	if(traverse->child != NULL){                          //this is for reaching the last base station of tree so that after deletion we don't lose access to other base stations
		traverse->child = close(traverse->child);
	}
	if(traverse->next!=NULL){                            // this is also for reaching the last base station (its next and child is NULL)   
		traverse-> next = close(traverse->next);
	}
	
	if(traverse->next==NULL && traverse->child==NULL ){   // if we reach that base station delete its mobile hosts and then delete the base station itself
		if(traverse->linklist != NULL){
			close_mh(traverse->linklist);
		}
		delete traverse;
		return NULL;
	}
		return traverse;
}
mobile_host* List::close_mh(mobile_host* traverse){        // this function deletes mobile host nodes of each base station
	
	if(traverse->next != NULL){
		traverse->next = close_mh(traverse->next);         // this recursive call is for reaching the last mobile host of that base station 
	}
	if(traverse->next == NULL){
		delete traverse;                                   // deleting that mobile host
		return NULL;
	}
	return traverse;
	
}

